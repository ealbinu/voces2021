$('.my-paroller').paroller();






var vm = new Vue({
    el: '#tablas',
    data () {
        return {
            tabla18Oct: tabla18,
            tabla19Oct: tabla19,
            tabla20Oct: tabla20,
            tabla21Oct: tabla21,
            tabla22Oct: tabla22,
            tablaActividades: tablaAct
        }
    }

})

